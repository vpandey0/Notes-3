﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using PracticeMvc.Models;
using PracticeMvc.Repository;
namespace PracticeMvc.Controllers
{
    public class StudentController : Controller
    {
        IStudent stuRepo = new StudentRepo();
        // GET: Student
        [HttpGet]
        public ActionResult AddStudentData()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddStudentData(Student s)
        {
            if(ModelState.IsValid)
            {
                stuRepo.AddStudent(s);
                 ModelState.Clear();
            }
           
           

            return View();
        }

    }
}