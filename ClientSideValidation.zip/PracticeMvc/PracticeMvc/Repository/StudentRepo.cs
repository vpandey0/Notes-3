﻿using System;
using System.Collections.Generic;
using System.Linq;
using PracticeMvc.Models;
using PracticeMvc.Database;


namespace PracticeMvc.Repository
{
    public class StudentRepo : IStudent
    {
        StudentContext stuC=new StudentContext();
        void IStudent.AddStudent(Student stu)
        {
            stuC.Students.Add(stu);
            stuC.SaveChanges();
           
        }

        void IStudent.UpdateStudent()
        {
          
        }
    }
}