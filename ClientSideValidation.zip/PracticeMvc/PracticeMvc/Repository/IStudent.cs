﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticeMvc.Models;

namespace PracticeMvc.Repository
{
    public interface IStudent
    {
        void AddStudent(Student stu);
        void UpdateStudent();
    }
}
