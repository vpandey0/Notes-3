﻿using System;


namespace PracticeMvc.ViewModel
{
    public class StudentViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}