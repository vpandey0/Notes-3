﻿using RelationshipFluentApi_Final.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RelationshipFluentApi_Final.Database;

namespace RelationshipFluentApi_Final.Repository
{
    public class UserRepository : IUserRepository
    {
        UserManagementContext userDb=new UserManagementContext();
        public UserRepository() { }
       

        int IUserRepository.CreateUser(UserProfileViewModel user)
        {
           User u= new User();
            u.Name = user.Name;
            u.Email = user.Email;
            u.UserProfile = new Profile();
            u.UserProfile.ProfileName = user.ProfileName;
            u.UserProfile.Description = user.Description;
            userDb.Users.Add(u);
           return  userDb.SaveChanges();
        }

        int IUserRepository.DeleteUser(int id)
        {
            throw new NotImplementedException();
        }

        IEnumerable<UserProfileViewModel> IUserRepository.GetUserDetail()
        {
            throw new NotImplementedException();
        }

        UserProfileViewModel IUserRepository.SearchUser(int id)
        {
            throw new NotImplementedException();
        }

        int IUserRepository.UpdateUser(User user)
        {
            throw new NotImplementedException();
        }
    }
}