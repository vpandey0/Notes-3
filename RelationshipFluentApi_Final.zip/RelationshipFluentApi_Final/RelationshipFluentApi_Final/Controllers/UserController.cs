﻿using RelationshipFluentApi_Final.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RelationshipFluentApi_Final.Models;

namespace RelationshipFluentApi_Final.Controllers
{
    public class UserController : Controller
    {
        IUserRepository userRepo = new UserRepository();
        // GET: User
        [HttpGet]
        public ActionResult CreateUserProfile()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateUserProfile(UserProfileViewModel userView)
        {
            var result=userRepo.CreateUser(userView);
            Response.Write(result);
            return View();
        }
    }
}