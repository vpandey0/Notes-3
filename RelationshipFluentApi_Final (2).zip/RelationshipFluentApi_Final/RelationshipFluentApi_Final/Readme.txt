﻿Agenda:
Relationship, Fluent Api, Post operation for multiple tables(Best Practice)