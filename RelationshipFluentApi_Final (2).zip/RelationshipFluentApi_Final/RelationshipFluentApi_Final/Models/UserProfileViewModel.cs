﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RelationshipFluentApi_Final.Models
{
    public class UserProfileViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string ProfileName { get; set; }
        public string Description { get; set; }


    }
}